package re;

import fa.nfa.NFA;

public interface REInterface {
	
	public abstract NFA getNFA();

}